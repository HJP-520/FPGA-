// =============================================================================
// tb_ser96to24.v —— 96->24 串化器 TB：随机空拍 + 帧边界标志 + 队列自检
// 验收：输入侧 4 像素/拍全展开，sof/eol 标志逐像素正确，无丢失/乱序。
// =============================================================================
`timescale 1ns/1ps
module tb_ser96to24;
    localparam W = 64, H = 8, BEATS = W/4, FRAME_BEATS = BEATS*H, FRAMES = 3;

    reg clk = 0, rst_n = 0;
    always #7 clk = ~clk;

    reg [95:0] tdata;
    reg        tvalid, tuser, tlast;
    wire       tready;
    wire       o_valid, o_sof, o_eol;
    wire [23:0] o_data;

    ser96to24 dut (.I_clk(clk), .I_rst_n(rst_n),
        .I_tdata(tdata), .I_tvalid(tvalid), .I_tuser(tuser), .I_tlast(tlast),
        .O_tready(tready),
        .O_valid(o_valid), .O_sof(o_sof), .O_eol(o_eol), .O_data(o_data));

    // 期望队列
    reg [23:0] exp_d [0:FRAMES*W*H-1];
    reg        exp_s [0:FRAMES*W*H-1];
    reg        exp_e [0:FRAMES*W*H-1];
    integer    push_n = 0, pop_n = 0, mism = 0;
    integer    f, b, k, i;
    reg [15:0] lfsr = 16'hBEEF;
    reg        drv_valid;

    // 输入驱动
    initial begin
        tdata = 0; tvalid = 0; tuser = 0; tlast = 0;
        repeat (4) @(posedge clk);
        rst_n <= 1;
        for (f = 0; f < FRAMES; f = f + 1) begin
            for (b = 0; b < FRAME_BEATS; b = b + 1) begin
                // 总线契约：beat 率 = 像素率/4（4 拍 1 beat），另有少量随机额外空闲
                repeat (3) begin
                    @(posedge clk);
                    tvalid <= 1'b0;
                end
                lfsr = {lfsr[14:0], lfsr[15]^lfsr[13]^lfsr[12]^lfsr[10]};
                drv_valid = (lfsr[2:0] != 3'b000);
                while (!drv_valid) begin
                    @(posedge clk);
                    tvalid <= 1'b0;
                    lfsr = {lfsr[14:0], lfsr[15]^lfsr[13]^lfsr[12]^lfsr[10]};
                    drv_valid = (lfsr[2:0] != 3'b000);
                end
                @(posedge clk);
                tvalid <= 1'b1;
                for (k = 0; k < 4; k = k + 1) begin
                    tdata[95-24*k -: 24] <= 24'h100000 * f + b * 4 + k;
                    exp_d[push_n + k] = 24'h100000 * f + b * 4 + k;
                    exp_s[push_n + k] = (b == 0) && (k == 0);
                    exp_e[push_n + k] = (k == 3) && ((b % BEATS) == BEATS-1);
                end
                tuser <= (b == 0);
                tlast <= ((b % BEATS) == BEATS-1);
                push_n = push_n + 4;
            end
        end
        @(posedge clk);
        tvalid <= 1'b0; tuser <= 1'b0; tlast <= 1'b0;
        repeat (64) @(posedge clk);
        if ((mism == 0) && (pop_n == push_n))
            $display("TB_RESULT: PASS (pixels=%0d)", pop_n);
        else
            $display("TB_RESULT: FAIL mism=%0d pop=%0d push=%0d", mism, pop_n, push_n);
        $finish;
    end

    // 输出比对
    always @(posedge clk) begin
        if (rst_n && o_valid) begin
            if ((o_data !== exp_d[pop_n]) || (o_sof !== exp_s[pop_n]) ||
                (o_eol !== exp_e[pop_n])) begin
                if (mism < 8)
                    $display("MISM idx=%0d got d=%h s=%b e=%b exp d=%h s=%b e=%b",
                             pop_n, o_data, o_sof, o_eol,
                             exp_d[pop_n], exp_s[pop_n], exp_e[pop_n]);
                mism = mism + 1;
            end
            pop_n = pop_n + 1;
        end
    end

    initial begin
        #20000000;
        $display("TB_RESULT: FAIL timeout");
        $finish;
    end
endmodule
