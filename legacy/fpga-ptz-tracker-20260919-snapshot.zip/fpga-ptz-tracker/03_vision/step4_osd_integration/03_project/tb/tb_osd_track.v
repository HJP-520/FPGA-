// =============================================================================
// tb_osd_track.v —— OSD 叠加层帧级校验：底图(osd_base.hex) + 目标包
// -> 输出帧(osd_act.hex) 交 Python 与 osd_exp.hex 逐像素比对。
// 目标包来自 osd_coord.txt（与金标准渲染同源）。
// =============================================================================
`timescale 1ns/1ps
module tb_osd_track;
    reg clk = 0, rst_n = 0;
    always #7 clk = ~clk;

    reg        in_valid, in_sof, in_eol;
    reg [23:0] in_data;
    wire       o_valid, o_sof, o_eol;
    wire [23:0] o_data;

    reg  [67:0] pack;
    reg         pack_load = 0;
    wire        pack_busy;

    osd_track dut (
        .I_clk(clk), .I_rst_n(rst_n),
        .I_valid(in_valid), .I_sof(in_sof), .I_eol(in_eol), .I_data(in_data),
        .I_det_clk(clk), .I_det_rst_n(rst_n),
        .I_det_pack(pack), .I_det_load(pack_load), .O_det_busy(pack_busy),
        .O_valid(o_valid), .O_sof(o_sof), .O_eol(o_eol), .O_data(o_data));

    reg [23:0] base [0:1280*720-1];
    integer fdm, fdo, i = 0, x = 0, y = 0;
    integer fdc, scanned;
    reg v_in; integer c_cx, c_cy, c_x0, c_x1, c_y0, c_y1;

    initial begin
        $readmemh("osd_base.hex", base);
        fdc = $fopen("osd_coord.txt", "r");
        scanned = $fscanf(fdc, "%1x%3x%3x%3x%3x%3x%3x",
                          v_in, c_cx, c_cy, c_x0, c_x1, c_y0, c_y1);
        pack = {v_in, 3'd0, c_cx[10:0], c_cy[10:0], c_x0[10:0], c_x1[10:0],
                c_y0[9:0], c_y1[9:0]};
        $display("SCAN scanned=%0d v_in=%b cx=%0d cy=%0d x0=%0d x1=%0d y0=%0d y1=%0d pack=%067b",
                 scanned, v_in, c_cx, c_cy, c_x0, c_x1, c_y0, c_y1, pack);
    end

    // 先发坐标包，再放视频
    initial begin
        repeat (3) @(posedge clk);
        rst_n <= 1;
        repeat (2) @(posedge clk);
        pack_load <= 1'b1;
        @(posedge clk);
        pack_load <= 1'b0;
        wait (!pack_busy);
        @(posedge clk);
        $display("AFTERLOAD tv=%b dst66=%b dst=%067b", dut.tv, dut.pack_dst[66], dut.pack_dst);
        fdo = $fopen("osd_act.hex", "w");
        $display("TXTBUF tv=%b txt=%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s",
          dut.tv, dut.txt[0],dut.txt[1],dut.txt[2],dut.txt[3],dut.txt[4],
          dut.txt[5],dut.txt[6],dut.txt[7],dut.txt[8],dut.txt[9],dut.txt[10],
          dut.txt[11],dut.txt[12],dut.txt[13],dut.txt[14],dut.txt[15],
          dut.txt[16],dut.txt[17],dut.txt[18],dut.txt[19]);
    end

    // 驱动底图并采集输出
    always @(posedge clk) begin
        if (rst_n && fdo != 0 && (i < 1280*720)) begin
            in_valid <= 1'b1;
            in_data  <= base[i];
            in_sof   <= (i == 0);
            in_eol   <= (x == 1280-1);
            if (x == 1280-1) begin
                x <= 0; y <= y + 1;
            end else begin
                x <= x + 1;
            end
            i = i + 1;
        end else begin
            in_valid <= 1'b0; in_sof <= 1'b0; in_eol <= 1'b0;
        end
    end

    integer got = 0;
    always @(posedge clk) begin
        if (rst_n && o_valid) begin
            $fwrite(fdo, "%02X%02X%02X\n", o_data[23:16], o_data[15:8], o_data[7:0]);
            got = got + 1;
            if (got == 1280*720) begin
                $fflush(fdo);
                $fclose(fdo);
                $display("TB_RESULT: PASS (dumped=%0d, expect python compare)", got);
                $finish;
            end
        end
    end

    initial begin
        #60000000;
        $display("TB_RESULT: FAIL timeout got=%0d", got);
        $finish;
    end
endmodule
