// =============================================================================
// vision_top.v —— 视觉方向自研部分整机顶层
// -----------------------------------------------------------------------------
// 数据流：
//   96bit AXI-S 视频输入（上板=isp_top 输出；仿真=tpg/sim_video_src）
//     ├─ 直通输出（与输入逐拍一致，继续走 DDR/HDMI 主线）
//     └─ detect_top（窃流检测链）→ 每帧目标包
//          ├─ cdc_4phase → osd_track（叠加十字/框/状态文字）→ O_osd_* 输出
//          └─ pulse_sync(frame_tick) + cdc_4phase(坐标) → gimbal_ctrl
//               → pwm_servo → O_pwm_x/O_pwm_y（50MHz 域，上板接 40Pin DC3）
// 时钟域：I_pix_clk（视频/检测/OSD，上板 74.25M）、I_pwm_clk（50M 整数域）。
// 上板挂载：本模块整体例化进 design_top_wrapper.v（见 06_interfaces）。
// =============================================================================
module vision_top #(
    parameter IMG_WIDTH    = 1280,
    parameter IMG_HEIGHT   = 720,
    parameter MIN_PIXELS   = 30,
    // 云台控制参数（现场整定，最终固化进 bit）
    parameter KP_X         = 20,
    parameter KP_Y         = 18,
    parameter DZ_X         = 25,
    parameter DZ_Y         = 20,
    parameter SLEW_US      = 100,
    parameter SERVO_MIN_US = 700,
    parameter SERVO_MAX_US = 2300,
    parameter INVERT_X     = 0,
    parameter INVERT_Y     = 0
)(
    input  wire        I_pix_clk,
    input  wire        I_pix_rst_n,
    input  wire        I_pwm_clk,
    input  wire        I_pwm_rst_n,
    // 96bit 视频输入（窃流）
    input  wire [95:0] I_tdata,
    input  wire        I_tvalid,
    input  wire        I_tuser,
    input  wire        I_tlast,
    output wire        O_tready,
    // 直通输出
    output wire [95:0] O_tdata,
    output wire        O_tvalid,
    output wire        O_tuser,
    output wire        O_tlast,
    // 叠加后 1ppc 输出（上板送显示侧 OSD 混合；仿真送帧转储）
    output wire        O_osd_valid,
    output wire        O_osd_sof,
    output wire        O_osd_eol,
    output wire [23:0] O_osd_data,
    // 控制
    input  wire [2:0]  I_preset_idx,     // 阈值组（按键/拨码）
    input  wire        I_track_en,       // 跟踪使能（0=云台回中）
    // 云台输出（50MHz 域）
    output wire        O_pwm_x,
    output wire        O_pwm_y,
    output wire [12:0] O_duty_x_us,
    output wire [12:0] O_duty_y_us,
    output wire [15:0] O_lost_cnt,
    output wire [7:0]  O_status
);

    // 串化后 1ppc 底图流（detect_top -> osd_track）
    wire        det_s_valid, det_s_sof, det_s_eol;
    wire [23:0] det_s_data;

    // ---------------- 检测分支 ----------------
    wire         t_valid, t_upd, t_tick;
    wire [10:0]  t_cx, t_cy, t_minx, t_maxx;
    wire [9:0]   t_miny, t_maxy;
    wire [20:0]  t_cnt;
    wire [15:0]  lost_det;
    detect_top #(
        .IMG_WIDTH(IMG_WIDTH), .IMG_HEIGHT(IMG_HEIGHT), .MIN_PIXELS(MIN_PIXELS)
    ) u_det (
        .I_clk(I_pix_clk), .I_rst_n(I_pix_rst_n),
        .I_tdata(I_tdata), .I_tvalid(I_tvalid), .I_tuser(I_tuser), .I_tlast(I_tlast),
        .O_tready(O_tready),
        .O_tdata(O_tdata), .O_tvalid(O_tvalid), .O_tuser(O_tuser), .O_tlast(O_tlast),
        .I_preset_idx(I_preset_idx),
        .O_target_valid(t_valid), .O_cx(t_cx), .O_cy(t_cy), .O_count(t_cnt),
        .O_min_x(t_minx), .O_max_x(t_maxx), .O_min_y(t_miny), .O_max_y(t_maxy),
        .O_lost_cnt(lost_det), .O_results_upd(t_upd), .O_frame_tick(t_tick),
        .O_dbg_mask_valid(), .O_dbg_mask(),
        .O_s_valid(det_s_valid), .O_s_sof(det_s_sof),
        .O_s_eol(det_s_eol), .O_s_data(det_s_data)
    );

    // ---------------- OSD 路径（同 I_pix_clk 域；上板可与显示域异步） ----
    wire [67:0] pack_vision = {t_valid, I_preset_idx, t_cx, t_cy,
                               t_minx, t_maxx, t_miny, t_maxy};  // 68b
    osd_track #(
        .IMG_WIDTH(IMG_WIDTH), .IMG_HEIGHT(IMG_HEIGHT)
    ) u_osd (
        .I_clk(I_pix_clk), .I_rst_n(I_pix_rst_n),
        // OSD 层输入 = 串化后的 1ppc 原始流（detect_top 内部 ser 的输出）
        .I_valid(det_s_valid), .I_sof(det_s_sof),
        .I_eol(det_s_eol), .I_data(det_s_data),
        .I_det_clk(I_pix_clk), .I_det_rst_n(I_pix_rst_n),
        .I_det_pack(pack_vision), .I_det_load(t_upd), .O_det_busy(),
        .O_valid(O_osd_valid), .O_sof(O_osd_sof), .O_eol(O_osd_eol),
        .O_data(O_osd_data)
    );

    // ---------------- 云台控制路径（50MHz 域） ----------------
    wire tick_pwm;
    pulse_sync u_tick_sync (
        .I_clk_src(I_pix_clk), .I_rst_src_n(I_pix_rst_n), .I_pulse_src(t_tick),
        .I_clk_dst(I_pwm_clk), .I_rst_dst_n(I_pwm_rst_n), .O_pulse_dst(tick_pwm)
    );

    wire [22:0] ctrl_pack_src = {t_valid, t_cx, t_cy};
    wire [22:0] ctrl_pack_dst;
    wire        ctrl_valid_dst;
    reg  [22:0] ctrl_hold;
    reg         ctrl_vld_hold;
    cdc_4phase #(.WIDTH(23)) u_ctrl_cdc (
        .I_clk_src(I_pix_clk), .I_rst_src_n(I_pix_rst_n),
        .I_src_data(ctrl_pack_src), .I_src_load(t_upd), .O_src_busy(),
        .I_clk_dst(I_pwm_clk), .I_rst_dst_n(I_pwm_rst_n),
        .O_dst_data(ctrl_pack_dst), .O_dst_valid(ctrl_valid_dst)
    );
    // 目标包与帧拍可能倒序到达：有效包先缓存，帧拍时交控制律
    always @(posedge I_pwm_clk or negedge I_pwm_rst_n) begin
        if (!I_pwm_rst_n) begin
            ctrl_hold <= 23'd0; ctrl_vld_hold <= 1'b0;
        end else begin
            if (ctrl_valid_dst) begin
                ctrl_hold     <= ctrl_pack_dst;
                ctrl_vld_hold <= ctrl_pack_dst[22];
            end
            if (tick_pwm)
                ctrl_vld_hold <= 1'b0;   // 帧拍消费后失效（保守：每帧一次）
        end
    end

    wire [12:0] duty_x, duty_y;
    gimbal_ctrl #(
        .KP_X(KP_X), .KP_Y(KP_Y), .DZ_X(DZ_X), .DZ_Y(DZ_Y),
        .SLEW_US(SLEW_US), .SERVO_MIN_US(SERVO_MIN_US), .SERVO_MAX_US(SERVO_MAX_US),
        .CENTER_X(IMG_WIDTH/2), .CENTER_Y(IMG_HEIGHT/2),
        .INVERT_X(INVERT_X), .INVERT_Y(INVERT_Y)
    ) u_gimbal (
        .I_clk(I_pwm_clk), .I_rst_n(I_pwm_rst_n),
        .I_frame_tick(tick_pwm), .I_track_en(I_track_en),
        .I_target_valid(ctrl_vld_hold),
        .I_cx(ctrl_hold[21:11]), .I_cy(ctrl_hold[10:0]),
        .O_duty_x_us(duty_x), .O_duty_y_us(duty_y),
        .O_lost_cnt(O_lost_cnt), .O_status(O_status)
    );

    pwm_servo u_pwm (
        .I_clk(I_pwm_clk), .I_rst_n(I_pwm_rst_n),
        .I_update(tick_pwm),
        .I_duty_x_us(duty_x), .I_duty_y_us(duty_y),
        .O_pwm_x(O_pwm_x), .O_pwm_y(O_pwm_y),
        .O_period_tick(), .O_duty_x_dbg(O_duty_x_us), .O_duty_y_dbg(O_duty_y_us)
    );

endmodule
