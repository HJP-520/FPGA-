// =============================================================================
// osd_track.v —— 跟踪信息 OSD 叠加层（十字准星 + 包围框 + 状态文字）
// -----------------------------------------------------------------------------
// 输入：1ppc vpix 流（valid/sof/eol/data，内部推导 x/y 计数）
// CDC：检测域 67bit 目标包 {valid,preset[2:0],cx,cy,minx,maxx,miny,maxy}
//      经 4 相握手写入（每帧一次，准静态——整帧期间寄存器稳定）。
// 绘制优先级（高->低）：状态文字(白) > 十字准星(绿) > 包围框(红) > 底图。
//   文字："TRK<n> LOCK X%04dY%04d" / "TRK<n> LOST X----Y----"，
//         8x16 点阵，左上角固定 (16,16)，20 字符。
//   十字：臂长 12、中空半径 3（±3..±12），绿色 00FF00。
//   框：bbox 边缘内缩 2px，红色 FF0000。
// 上板挂载：display 侧从 hdmi_mixer 取流（DE→valid 约定见 IF-OSD.md）。
// 已知限制：坐标包到达与显示场消隐不同步，存在理论撕裂窗口（单帧一次
// 更新，概率极低）；v2 改双缓冲+显示 vsync 交换（见迭代文件）。
// =============================================================================
module osd_track #(
    parameter IMG_WIDTH  = 1280,
    parameter IMG_HEIGHT = 720,
    parameter TXT_X0     = 16,
    parameter TXT_Y0     = 16
)(
    input  wire        I_clk,
    input  wire        I_rst_n,
    // vpix 输入
    input  wire        I_valid,
    input  wire        I_sof,
    input  wire        I_eol,
    input  wire [23:0] I_data,
    // 检测域接口（CDC 4 相握手源侧）
    input  wire        I_det_clk,
    input  wire        I_det_rst_n,
    input  wire [67:0] I_det_pack,     // {valid,preset[2:0],cx,cy,minx,maxx,miny,maxy} = 68b
    input  wire        I_det_load,
    output wire        O_det_busy,
    // vpix 输出（叠加后）
    output reg         O_valid,
    output reg         O_sof,
    output reg         O_eol,
    output reg  [23:0] O_data
);

    // ---------------- CDC ----------------
    wire [67:0] pack_dst;
    wire        pack_valid;
    cdc_4phase #(.WIDTH(68)) u_cdc (
        .I_clk_src(I_det_clk), .I_rst_src_n(I_det_rst_n),
        .I_src_data(I_det_pack), .I_src_load(I_det_load), .O_src_busy(O_det_busy),
        .I_clk_dst(I_clk), .I_rst_dst_n(I_rst_n),
        .O_dst_data(pack_dst), .O_dst_valid(pack_valid)
    );

    // ---------------- 目标寄存器（准静态） ----------------
    reg        tv;                      // target valid
    reg [10:0] cx, cy, bminx, bmaxx;
    reg [9:0]  bminy, bmaxy;
    reg [2:0]  preset_q;
    reg [7:0]  txt [0:19];              // 20 字符状态文字
    integer    k;

    // 二进制 -> 4 位十进制 ASCII（除常数，帧率更新，时序充裕）
    function [31:0] to_digits4;         // 返回 4 个 ASCII
        input [10:0] val;
        reg [11:0] r;
        begin
            to_digits4[31:24] = 8'd48 + val / 11'd1000;
            r = val % 11'd1000;
            to_digits4[23:16] = 8'd48 + r / 12'd100;
            r = r % 12'd100;
            to_digits4[15:8]  = 8'd48 + r / 12'd10;
            to_digits4[7:0]   = 8'd48 + r % 12'd10;
        end
    endfunction

    reg [31:0] d_x, d_y;
    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            tv <= 1'b0; cx <= 11'd0; cy <= 11'd0;
            bminx <= 11'd0; bmaxx <= 11'd0; bminy <= 10'd0; bmaxy <= 10'd0;
            preset_q <= 3'd0;
            for (k = 0; k < 20; k = k + 1) txt[k] <= 8'd32;
        end else if (pack_valid) begin
            tv      <= pack_dst[67];
            preset_q<= pack_dst[66:64];
            cx      <= pack_dst[63:53];
            cy      <= pack_dst[52:42];
            bminx   <= pack_dst[41:31];
            bmaxx   <= pack_dst[30:20];
            bminy   <= pack_dst[19:10];
            bmaxy   <= pack_dst[9:0];
            // "TRK0 LOCK X0640Y0360"
            txt[0] <= "T"; txt[1] <= "R"; txt[2] <= "K";
            txt[3] <= 8'd48 + {5'd0, pack_dst[66:64]};
            if (pack_dst[67]) begin   // valid 位（68b 包）
                txt[4] <= " "; txt[5] <= "L"; txt[6] <= "O"; txt[7] <= "C";
                txt[8] <= "K"; txt[9] <= " "; txt[10] <= "X";
            end else begin
                txt[4] <= " "; txt[5] <= "L"; txt[6] <= "O"; txt[7] <= "S";
                txt[8] <= "T"; txt[9] <= " "; txt[10] <= "X";
            end
            d_x = to_digits4(pack_dst[67] ? pack_dst[63:53] : 11'd0);
            d_y = to_digits4(pack_dst[67] ? pack_dst[52:42] : 11'd0);
            if (!pack_dst[67]) begin
                d_x = 32'h2D2D2D2D;           // "----"
                d_y = 32'h2D2D2D2D;
            end
            txt[11] <= d_x[31:24]; txt[12] <= d_x[23:16];
            txt[13] <= d_x[15:8];  txt[14] <= d_x[7:0];
            txt[15] <= "Y";
            txt[16] <= d_y[31:24]; txt[17] <= d_y[23:16];
            txt[18] <= d_y[15:8];  txt[19] <= d_y[7:0];
        end
    end

    // ---------------- x/y 计数 ----------------
    reg [10:0] px;
    reg [9:0]  py;
    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            px <= 11'd0; py <= 10'd0;
        end else if (I_valid) begin
            if (I_sof) begin
                px <= 11'd1; py <= 10'd0;      // sof = (0,0)
            end else if (I_eol) begin
                px <= 11'd0; py <= py + 10'd1;
            end else begin
                px <= px + 11'd1;
            end
        end
    end

    // ---------------- 叠加判决（组合） ----------------
    wire in_txt = (py >= TXT_Y0) && (py < TXT_Y0 + 16) &&
                  (px >= TXT_X0) && (px < TXT_X0 + 160);
    wire [4:0]  ch_idx = (px - TXT_X0) >> 3;
    wire [3:0]  ch_row = py - TXT_Y0;
    wire [10:0] dxp = px - TXT_X0;
    wire [2:0]  bit_sel = 3'd7 - dxp[2:0];
    wire [7:0]  glyph;
    font_rom_8x16 u_font (.I_addr({txt[ch_idx], ch_row}), .O_bits(glyph));
    wire on_txt = in_txt && glyph[bit_sel];

    wire signed [12:0] dx_c = $signed({1'b0, px}) - $signed({1'b0, cx});
    wire signed [12:0] dy_c = $signed({1'b0, py}) - $signed({1'b0, cy});
    wire ax = (dx_c >= -13'sd12) && (dx_c <= 13'sd12) &&
              ((dx_c <= -13'sd3) || (dx_c >= 13'sd3));
    wire ay = (dy_c >= -13'sd12) && (dy_c <= 13'sd12) &&
              ((dy_c <= -13'sd3) || (dy_c >= 13'sd3));
    wire on_cross = tv && ((ay && (dx_c == 13'sd0)) || (ax && (dy_c == 13'sd0)));

    wire x_edge = (px == bminx) || (px == bminx + 11'd1) ||
                  (px == bmaxx - 11'd1) || (px == bmaxx);
    wire y_edge = (py == bminy) || (py == bminy + 10'd1) ||
                  (py == bmaxy - 10'd1) || (py == bmaxy);
    wire in_box_x = (px >= bminx) && (px <= bmaxx);
    wire in_box_y = (py >= bminy) && (py <= bmaxy);
    wire on_box = tv && ((x_edge && in_box_y) || (y_edge && in_box_x));

    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            O_valid <= 1'b0; O_sof <= 1'b0; O_eol <= 1'b0; O_data <= 24'd0;
        end else begin
            O_valid <= I_valid;
            O_sof   <= I_sof;
            O_eol   <= I_eol;
            O_data  <= on_txt ? 24'hFF_FF_FF :
                       on_cross ? 24'h00_FF_00 :
                       on_box ? 24'hFF_00_00 : I_data;
        end
    end

endmodule
