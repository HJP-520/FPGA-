# fpga-ptz-tracker —— 视觉方向软件包

2026 FPGA 创新设计赛道（安路）赛题二：基于 PH1P35 的实时数字图像处理系统。
本仓库 = **视觉方向**全部软件资产：检测链 RTL、OSD 叠加、云台闭环控制、
金标准模型、测试向量、仿真套件与全套文档。

## 当前状态（2026-09-19）

- **整体回归 14/14 全绿**（ModelSim，`python tools/run_all.py`）
- 闭环在环仿真：36 帧锁定（相机-舵机模型），无振荡
- OSD 整帧 921600 像素与金标准逐位一致
- 无硬件：全部验证在仿真层完成；上板挂载说明在 `04_embedded/`

## 目录结构（对应项目地图六大分区）

```
01_official/          官方资料索引（原文件在 D 盘原位）
02_meetings/          决策纪要
03_vision/            ★ 视觉方向四步（每步四件套：方案对比/技术文档/工程文件/迭代文件）
  step1_video_link/       基座：串化器/TPG/仿真源/CDC
  step2_color_centroid/   检测链：HSV→阈值→平滑→质心
  step3_closed_loop/      云台控制律 + PWM
  step4_osd_integration/  OSD 叠加 + 整机顶层 + 闭环在环
04_embedded/          嵌入式方向交接说明（挂载/引脚/验收清单）
05_gimbal/            云台机械/电气/标定
06_interfaces/current/  接口统一文档（唯一生效版）
tools/                金标准模型 + 向量生成 + 测试调度（Python）
使用文档_视觉方向软件包.md
```

## 快速开始

```bash
cd D:\fpga-ptz-tracker\tools
python gen_vectors.py     # 生成全部测试向量与两张自动 RTL 表
python run_all.py         # 全量 14 个仿真，约 10 分钟
python run_all.py tb_vision_top tb_closed_loop   # 只跑指定项
```

环境：Python 3.10（numpy/cv2）+ ModelSim（`D:\ModelSim\win64`，路径写死在 run_all.py）。

## 与嵌入式方向的接口

`06_interfaces/current/`：IF-MIPI（视频输入）、IF-DDR（旁路挂载）、
IF-VISION（目标包，强耦合点）、IF-SERVO-PWM（云台）、IF-OSD（显示侧）。

## 覆盖的赛题要求

| 要求 | 本包对应 |
|------|----------|
| 扩展① 图层叠加与文字 | OSD 文字层（TRK0 LOCK X..Y..） |
| 扩展④ 实时参数调节与 OSD | 阈值 8 组按键切换 + OSD 显示组号/状态 |
| 进阶② 目标跟踪与坐标标注 | 检测链 + 十字/框/坐标 OSD + 云台闭环 |
| 进阶③ 延迟可视化（可选） | OSD 帧计数扩展位（架构已留） |
