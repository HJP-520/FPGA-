// =============================================================================
// system_top.v —— 嵌入式方向系统集成顶层（仿真/TD 双用）
// -----------------------------------------------------------------------------
// 挂载关系（对应 06_interfaces/current 三份接口文档）：
//   虚拟/真实 RAW10 流 ─> isp_top（官方，CSI 解包在 PHY 侧已完成，此处从
//                          raw10_unpacket 输出界接入）─> 128bit DDR 写流
//   128bit ─data128_96(官方重排)─> 96bit ─> vision_top（视觉目标包/OSD/云台）
//   按键消抖 ─> 阈值组切换；UART 遥测输出目标状态
// 与官方例程的差异（全部为"增加"，无官方文件改动）：
//   1. 不含 DDR2/MIPI-PHY/HDMI 加密核（仿真以帧转储替代 HDMI；DDR 写流空置）
//   2. 新增 uart_telemetry 遥测
// 时钟：单域 axi4s_video_aclk（74.25M 级）；pwm_clk 50M 由引脚给入
// =============================================================================
module system_top #(
    parameter IMG_WIDTH  = 1280,
    parameter IMG_HEIGHT = 720,
    parameter CLK_DIV_UART = 646          // 74.25MHz/115200 ≈ 645
)(
    input  wire        I_clk,             // axi4s_video_aclk
    input  wire        I_rst_n,
    input  wire        I_pwm_clk,         // 50MHz
    input  wire        I_pwm_rst_n,
    // 虚拟/真实 RAW10 传感器流（真实板 = raw10_unpacket_2lane 输出）
    input  wire [39:0] I_raw10_data,
    input  wire        I_raw10_valid,
    input  wire        I_raw10_sof,
    input  wire        I_raw10_eol,
    // 按键（低有效，经消抖）
    input  wire [1:0]  I_btn_n,
    // 云台 PWM
    output wire        O_pwm_x,
    output wire        O_pwm_y,
    output wire [12:0] O_duty_x_us,
    output wire [12:0] O_duty_y_us,
    output wire [15:0] O_lost_cnt,
    // UART 遥测
    output wire        O_uart_txd,
    // 调试观察口
    output wire [23:0] O_osd_data,
    output wire        O_osd_valid
);

    // ---------------- 官方 ISP（RAW10 -> RGB 128bit） ----------------
    wire [127:0] isp_tdata;
    wire         isp_tvalid, isp_tuser, isp_tlast, isp_tready;
    wire         isp_up_tready;

    isp_top u_isp (
        .axi4s_video_aclk (I_clk),
        .I_rst_n          (I_rst_n),
        .I_tlast          (I_raw10_eol),
        .I_tuser          (I_raw10_sof),
        .I_tdata          (I_raw10_data),
        .I_tvalid         (I_raw10_valid & isp_tready),
        .I_tdest          (10'd0),
        .O_tready         (isp_tready),
        .O_tdata          (isp_tdata),
        .O_tlast          (isp_tlast),
        .O_tuser          (isp_tuser),
        .O_tvalid         (isp_tvalid),
        .I_tready         (isp_up_tready)    // 对上游就绪指示（输出）
    );

    // ---------------- 官方 128->96 重排（零改动挂载点） ----------------
    wire [95:0] rgb96;
    data128_96 u_repack (.I_tdata(isp_tdata), .O_tdata(rgb96));

    // ---------------- 按键消抖（官方模块）-> 阈值组/跟踪使能 ----------------
    wire key0_trig, key1_trig;
    key_remove_shakes u_key0 (.I_clk(I_clk), .I_rst_n(I_rst_n),
        .I_key_in(~I_btn_n[0]), .O_key_trig_out(key0_trig));
    key_remove_shakes u_key1 (.I_clk(I_clk), .I_rst_n(I_rst_n),
        .I_key_in(~I_btn_n[1]), .O_key_trig_out(key1_trig));

    reg [2:0]  preset_idx  = 3'd0;
    reg        track_en    = 1'b1;
    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            preset_idx <= 3'd0;
            track_en   <= 1'b1;
        end else begin
            if (key0_trig) preset_idx <= preset_idx + 3'd1;   // KEY0: 切阈值组
            if (key1_trig) track_en   <= ~track_en;           // KEY1: 跟踪使能
        end
    end

    // ---------------- 视觉方向 vision_top（检测/OSD/云台） ----------------
    wire [95:0]  vis_pt_data;   // 视觉直通（本顶层不使用）
    wire         vis_pt_valid, vis_pt_user, vis_pt_last, vis_tready;
    wire         osd_valid, osd_sof, osd_eol;
    wire [23:0]  osd_data;
    wire [12:0]  duty_x, duty_y;
    wire [15:0]  lost_cnt;
    wire [7:0]   status;

    vision_top #(
        .IMG_WIDTH(IMG_WIDTH), .IMG_HEIGHT(IMG_HEIGHT)
    ) u_vision (
        .I_pix_clk    (I_clk),
        .I_pix_rst_n  (I_rst_n),
        .I_pwm_clk    (I_pwm_clk),
        .I_pwm_rst_n  (I_pwm_rst_n),
        .I_tdata      (rgb96),
        .I_tvalid     (isp_tvalid),
        .I_tuser      (isp_tuser),
        .I_tlast      (isp_tlast),
        .O_tready     (vis_tready),
        .O_tdata      (vis_pt_data),
        .O_tvalid     (vis_pt_valid),
        .O_tuser      (vis_pt_user),
        .O_tlast      (vis_pt_last),
        .O_osd_valid  (osd_valid),
        .O_osd_sof    (osd_sof),
        .O_osd_eol    (osd_eol),
        .O_osd_data   (osd_data),
        .I_preset_idx (preset_idx),
        .I_track_en   (track_en),
        .O_pwm_x      (O_pwm_x),
        .O_pwm_y      (O_pwm_y),
        .O_duty_x_us  (O_duty_x_us),
        .O_duty_y_us  (O_duty_y_us),
        .O_lost_cnt   (O_lost_cnt),
        .O_status     (status)
    );
    assign O_osd_valid = osd_valid;
    assign O_osd_data  = osd_data;
    assign vis_tready  = 1'b1;

    // ---------------- UART 遥测（新增 RTL；坐标经层次化引用） ----------------
    uart_telemetry #(.CLK_DIV(CLK_DIV_UART)) u_uart (
        .I_clk          (I_clk),
        .I_rst_n        (I_rst_n),
        .I_frame_tick   (u_vision.t_tick),
        .I_target_valid (u_vision.t_valid),
        .I_cx           (u_vision.t_cx),
        .I_cy           (u_vision.t_cy),
        .I_preset       (preset_idx),
        .O_txd          (O_uart_txd)
    );

    // 视觉内部信号（层次化引用），遥测用
endmodule
