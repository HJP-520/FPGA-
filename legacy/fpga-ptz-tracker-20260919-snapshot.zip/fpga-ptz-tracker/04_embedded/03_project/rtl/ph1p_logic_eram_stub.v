// =============================================================================
// ph1p_logic_eram_stub.v —— TD ERAM 原语的行为级替身（仅供仿真，TD 综合时用真原语）
// 端口清单来自官方 blk_mem 生成 RTL 的实例化（addra/addrb/dia/dib/cea/ceb/ocea/oceb/
// clka/clkb/wea/web/bea/beb/rsta/rstb/doa/dob + ecc 输出）。
// 行为：真双口 RAM，A 口写、B 口读写；bea/beb=0 表示全字节写（忽略）。
// =============================================================================
`timescale 1ns/1ps
module PH1P_LOGIC_ERAM #(
    parameter integer DATA_WIDTH_A = 20,
    parameter integer DATA_WIDTH_B = DATA_WIDTH_A,
    parameter integer ADDRA_WIDTH  = 14,
    parameter integer ADDRB_WIDTH  = ADDRA_WIDTH,
    parameter MODE               = "DP",
    parameter IMPLEMENT          = "20KFAST",
    parameter REGMODE_A          = "NORESET",
    parameter REGMODE_B          = "NORESET",
    parameter RESETMODE_A        = "SYNC",
    parameter RESETMODE_B        = "SYNC",
    parameter OREGSET_A          = "RESET",
    parameter OREGSET_B          = "RESET",
    parameter SYNC_RESET_RELEASE_A = "DISABLE",
    parameter SYNC_RESET_RELEASE_B = "DISABLE",
    parameter ASYNC_RESET_RELEASE_A = "ASYNC",
    parameter ASYNC_RESET_RELEASE_B = "ASYNC",
    parameter SSROVERCE          = "DISABLE",
    parameter ECC_ENCODE         = "DISABLE",
    parameter ECC_DECODE         = "DISABLE",
    parameter GSR                = "ENABLE",
    parameter RESETMODE          = "SYNC",
    parameter CLKMODE            = "ASYNC",
    parameter WRITEMODE_A        = "NORMAL",
    parameter WRITEMODE_B        = "NORMAL",
    parameter DATA_DEPTH_A       = 512,
    parameter DATA_DEPTH_B       = 512,
    parameter ADDR_WIDTH_A       = 9,
    parameter ADDR_WIDTH_B       = 9,
    parameter INIT_FILE          = "NONE",
    parameter FILL_ALL           = "NONE"
)(
    input  wire                     clka,
    input  wire                     clkb,
    input  wire [ADDRA_WIDTH-1:0]   addra,
    input  wire [ADDRB_WIDTH-1:0]   addrb,
    input  wire [DATA_WIDTH_A-1:0]  dia,
    input  wire [DATA_WIDTH_B-1:0]  dib,
    input  wire                     cea,
    input  wire                     ceb,
    input  wire                     ocea,
    input  wire                     oceb,
    input  wire                     wea,
    input  wire                     web,
    input  wire                     bea,
    input  wire                     beb,
    input  wire                     rsta,
    input  wire                     rstb,
    output reg  [DATA_WIDTH_A-1:0]  doa,
    output reg  [DATA_WIDTH_B-1:0]  dob,
    output wire                     ecc_sbiterr,
    output wire                     ecc_dbiterr,
    input  wire                     ecc_sbiterrinj,
    input  wire                     ecc_dbiterrinj
);
    localparam DEPTH = (1 << (ADDRA_WIDTH > 14 ? 14 : ADDRA_WIDTH));
    reg [DATA_WIDTH_A-1:0] mem [0:DEPTH-1];
    assign ecc_sbiterr = 0; assign ecc_dbiterr = 0;

    always @(posedge clka) begin
        if (cea && rsta) begin
            doa <= 0;
        end else if (cea) begin
            if (wea) mem[addra] <= dia;
            doa <= mem[addra];
        end
    end
    always @(posedge clkb) begin
        if (ceb && rstb) begin
            dob <= 0;
        end else if (ceb) begin
            if (web) mem[addrb] <= dib;
            dob <= mem[addrb];
        end
    end
endmodule

module PH1_LOGIC_ERAM #(
    parameter integer DATA_WIDTH_A = 20,
    parameter integer DATA_WIDTH_B = DATA_WIDTH_A,
    parameter integer ADDRA_WIDTH  = 14,
    parameter integer ADDRB_WIDTH  = ADDRA_WIDTH,
    parameter MODE               = "DP",
    parameter IMPLEMENT          = "20KFAST",
    parameter REGMODE_A          = "NORESET",
    parameter REGMODE_B          = "NORESET",
    parameter RESETMODE_A        = "SYNC",
    parameter RESETMODE_B        = "SYNC",
    parameter OREGSET_A          = "RESET",
    parameter OREGSET_B          = "RESET",
    parameter SYNC_RESET_RELEASE_A = "DISABLE",
    parameter SYNC_RESET_RELEASE_B = "DISABLE",
    parameter ASYNC_RESET_RELEASE_A = "ASYNC",
    parameter ASYNC_RESET_RELEASE_B = "ASYNC",
    parameter SSROVERCE          = "DISABLE",
    parameter ECC_ENCODE         = "DISABLE",
    parameter ECC_DECODE         = "DISABLE",
    parameter GSR                = "ENABLE",
    parameter RESETMODE          = "SYNC",
    parameter CLKMODE            = "ASYNC",
    parameter WRITEMODE_A        = "NORMAL",
    parameter WRITEMODE_B        = "NORMAL",
    parameter DATA_DEPTH_A       = 512,
    parameter DATA_DEPTH_B       = 512,
    parameter ADDR_WIDTH_A       = 9,
    parameter ADDR_WIDTH_B       = 9,
    parameter INIT_FILE          = "NONE",
    parameter FILL_ALL           = "NONE"
)(
    input  wire                     clka,
    input  wire                     clkb,
    input  wire [ADDRA_WIDTH-1:0]   addra,
    input  wire [ADDRB_WIDTH-1:0]   addrb,
    input  wire [DATA_WIDTH_A-1:0]  dia,
    input  wire [DATA_WIDTH_B-1:0]  dib,
    input  wire                     cea,
    input  wire                     ceb,
    input  wire                     ocea,
    input  wire                     oceb,
    input  wire                     wea,
    input  wire                     web,
    input  wire                     bea,
    input  wire                     beb,
    input  wire                     rsta,
    input  wire                     rstb,
    output reg  [DATA_WIDTH_A-1:0]  doa,
    output reg  [DATA_WIDTH_B-1:0]  dob,
    output wire                     ecc_sbiterr,
    output wire                     ecc_dbiterr,
    input  wire                     ecc_sbiterrinj,
    input  wire                     ecc_dbiterrinj
);
    localparam DEPTH = (1 << (ADDRA_WIDTH > 14 ? 14 : ADDRA_WIDTH));
    reg [DATA_WIDTH_A-1:0] mem [0:DEPTH-1];
    assign ecc_sbiterr = 0; assign ecc_dbiterr = 0;

    always @(posedge clka) begin
        if (cea && rsta) begin
            doa <= 0;
        end else if (cea) begin
            if (wea) mem[addra] <= dia;
            doa <= mem[addra];
        end
    end
    always @(posedge clkb) begin
        if (ceb && rstb) begin
            dob <= 0;
        end else if (ceb) begin
            if (web) mem[addrb] <= dib;
            dob <= mem[addrb];
        end
    end
endmodule
